<?php
	session_start();
	if(!isset($_SESSION['login'])){
		$_SESSION['login'] = false;
	}
	if($_SESSION['login']!=true){
		header('Location: index.php'); 
	}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<meta name="description" content="Créateur d'évènements">
<meta name="keywords" content="évènement, créer, fiesta, label fiesta">
<meta name="author" content="Max Borgeat">
<title>Evènement</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
      <!-- Own style -->
	  <link rel="stylesheet" href="style.css" >
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
         <div class="container">
            <div class="navbar-header">
               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               </button>
               <a class="navbar-brand" href="index.php">Fiesta</a>
            </div>
            <div id="navbar" class="collapse navbar-collapse" style="float:right;">
               <ul class="nav navbar-nav">
                  <li><a href="index.php">Home</a></li>
				  <?php if(!isset($_SESSION['login'])||$_SESSION['login']==false){ ?>
				  <li><a href="login.php">Login</a></li><?php } ?>
                  <?php if(isset($_SESSION['login'])&&$_SESSION['login']==true){ ?><li class="active"><a href="liste.php">Gérer</a></li>
                  <li><a href="create.php">Créer</a></li>
				  <li><a href="logout.php">Logout</a></li><?php } ?>
               </ul>
            </div>
            <!--/.nav-collapse -->
         </div>
      </nav>
	<div style="display:none;position:absolute;height:100%;width:100%;background-color:rgba(204, 204, 204, 0.3);text-align:center;"  id="ajax-loading"><img src="http://futureofmuseums.eu/wp-content/themes/museum/img/loader.gif" alt="Loading"/></div>

    <div class="container">
	<div class="starter-template">
      <table class="table table-striped" style="text-align:left">
		  <thead>
			<tr>
				<th>#</th>
				<th>Nom de l'événement</th>
				<th>Date de début</th>
				<th>Date de fin</th>
				<th></th>
			  </tr>
		  </thead>
		  <tbody id="listing">
			
		  </tbody>
	  </table>
</form>
</div>
    </div><!-- /.container -->
	<footer class="footer">
      <div class="container">
        <p class="text-muted">Email : <a href="mailto:contact@fiesta.ch">contact@fiesta.ch</a> / Tel : 0123 456 789</p>
      </div>
    </footer>



<script type="text/javascript">
function affiche(){
	$('#ajax-loading').show();
	$('#listing').empty();
	$.ajax({
            type: "GET",
            dataType: "jsonp",
            contentType: "application/json;charset=utf-8",
            url: "https://projetfiesta-1372.appspot.com/_ah/api/eventEntityApi/v1/eventEntity",
            success: function (data) {
                console.log(data);
					var id = 1;
				  $.each(data.items, function() {
					$('#listing').append("<tr><th scope='row'>"+id+"</th><td>"+this.name+"</td><td>"+this.beginning+"</td><td>"+this.end+"</td><td><a class='delete'  data-id='"+this.id+"'><i class='glyphicon glyphicon-trash'/></a></td></tr>");
					  id++;
				  });
				$('#ajax-loading').hide();
            },
            error: function (error) {
                console.log(error);
				$('#ajax-loading').hide();
            }
    });
}
$( window ).load(function() {
        affiche();
});
$( document ).ready(function() {
	$('body').on('click', '.delete', function (e){
        e.preventDefault();
		$('#ajax-loading').show();
		var id = $(this).data('id');
        $.ajax({
            type: "DELETE",
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            url: "https://projetfiesta-1372.appspot.com/_ah/api/eventEntityApi/v1/eventEntity/"+id,
            success: function (data) {
                alert('L\'événement a bien été supprimé !');
				affiche();
				$('#ajax-loading').hide();
            },
            error: function (error) {
                alert('Erreur lors de la suppression de l\'événement  !');
				$('#ajax-loading').hide();
            }
        });
    });
});

</script>
</body>
</html>




