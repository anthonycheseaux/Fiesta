<?php
   session_start();
   if(!isset($_SESSION['login'])){
		$_SESSION['login'] = false;
	}
?>

<!DOCTYPE html>
<html>
   <head>
      <meta charset="UTF-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

      <meta name="description" content="Créateur d'évènements">
      <meta name="keywords" content="évènement, créer, fiesta, label fiesta">
      <meta name="author" content="Max Borgeat">
      <title>Evènement</title>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <!-- Latest compiled and minified CSS -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <!-- Optional theme -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
      <!-- Own style -->
      <link rel="stylesheet" href="style.css" >
      <!-- Latest compiled and minified JavaScript -->
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
   </head>
   <body>
      <nav class="navbar navbar-inverse navbar-fixed-top">
         <div class="container">
            <div class="navbar-header">
               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               </button>
               <a class="navbar-brand" href="index.php">Fiesta</a>
            </div>
            <div id="navbar" class="collapse navbar-collapse" style="float:right;">
               <ul class="nav navbar-nav">
                  <li class="active"><a href="index.php">Home</a></li>
				  <?php if(!isset($_SESSION['login'])||$_SESSION['login']==false){ ?>
				  <li><a href="login.php">Login</a></li><?php } ?>
                  <?php if(isset($_SESSION['login'])&&$_SESSION['login']==true){ ?><li><a href="liste.php">Gérer</a></li>
                  <li><a href="create.php">Créer</a></li>
				  <li><a href="logout.php">Logout</a></li><?php } ?>
               </ul>
            </div>
            <!--/.nav-collapse -->
         </div>
      </nav>
      <div class="container">
         <div class="starter-template">
            <div class="row featurette">
               <div class="col-md-7 col-md-push-5">
                  <h2 class="featurette-heading">Faire la fête <span class="text-muted">sans prendre de risque !</span></h2>
                  <p class="lead">Notre nouvelle application vous permettra de trouver un moyen de rentrer chez vous après une soirée arrosée ! Comment cela vous dites vous ? Simplement en faisant confiance aux conducteurs sobre se trouvant à la même fête que vous !</p>
               </div>
               <div class="col-md-5 col-md-pull-7">
                  <img class="featurette-image img-responsive center-block" src="img/logo.png" alt="logo">
               </div>
            </div>
			<div style="padding-top:40px;padding-bottom:40px;">
			<p><a class="btn btn-lg btn-success" style="font-size:25px;" href="https://play.google.com/store?hl=fr" role="button">Télécharge notre application dès maintenant !</a></p>
			</div>
            <hr class="featurette-divider">
            <div class="row">
               <div class="col-lg-4">
                  <img class="img-circle" src="img/alcool.jpg" alt="alcool" width="140" height="140">
                  <h2>Trop bu ?</h2>
                  <p>C'est justement à vous que nous avons pensé dans cette application ! Il vous suffit de réserver votre chauffeur avant d'avoir trop bu, et pour ce faire, télécharger notre application !</p>
                  <p><a class="btn btn-default" href="https://play.google.com/store?hl=fr" role="button" target="_blank">Télécharger &raquo;</a></p>
               </div>
               <!-- /.col-lg-4 -->
               <div class="col-lg-4">
                  <img class="img-circle" src="img/volant.jpg" alt="volant" width="140" height="140">
                  <h2>Sobre ?</h2>
                  <p>C'est vous qui avez la voiture ce soir, et vous avez de la place de disponible ! Alors là aussi nous avons pensé à vous dans notre application, téléchargez-là et inscrivez vous en tant que chauffeur !</p>
                  <p><a class="btn btn-default" href="https://play.google.com/store?hl=fr" role="button" target="_blank">Télécharger &raquo;</a></p>
               </div>
               <!-- /.col-lg-4 -->
               <div class="col-lg-4">
                  <img class="img-circle" src="img/event.jpg" alt="event" width="140" height="140">
                  <h2>Administrateur ?</h2>
                  <p>Vous avez créer des événement et vous désirez les gérer ? Alors nous avons aussi pensé à vous ! Créer votre évènement dans notre admin et gérer les évènements déjà créé !</p>
                  <p><a class="btn btn-default" href="login.php" role="button">Se connecter &raquo;</a></p>
               </div>
               <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
         </div>
      </div>
      <!-- /.container -->
	  <footer class="footer">
      <div class="container">
        <p class="text-muted">Email : <a href="mailto:contact@fiesta.ch">contact@fiesta.ch</a> / Tel : 0123 456 789</p>
      </div>
    </footer>
   </body>
</html>