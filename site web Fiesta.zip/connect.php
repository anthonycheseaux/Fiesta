<?php
    $email = "admin@fiesta.ch";
    $password = "fiesta";
    if( isset($_POST['inputEmail']) && isset($_POST['inputPassword'])){

        if($_POST['inputEmail'] == $email && $_POST['inputPassword'] == $password){ // Si les infos correspondent...
            session_start();
            $_SESSION['login'] = true;
			header('Location: liste.php');        
        }
        else{ // Sinon
			header('Location: login.php?msg=failed'); 
        }

    }

?>

