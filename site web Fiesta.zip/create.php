<?php
	session_start();
	if(!isset($_SESSION['login'])){
		$_SESSION['login'] = false;
	}
	if($_SESSION['login']!=true){
		header('Location: index.php'); 
	}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<meta name="description" content="Créateur d'évènements">
<meta name="keywords" content="évènement, créer, fiesta, label fiesta">
<meta name="author" content="Max Borgeat">
<title>Evènement</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
      <!-- Own style -->
	  <link rel="stylesheet" href="style.css" >
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
         <div class="container">
            <div class="navbar-header">
               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               </button>
               <a class="navbar-brand" href="index.php">Fiesta</a>
            </div>
            <div id="navbar" class="collapse navbar-collapse" style="float:right;">
               <ul class="nav navbar-nav">
                  <li><a href="index.php">Home</a></li>
				  <?php if(!isset($_SESSION['login'])||$_SESSION['login']==false){ ?>
				  <li><a href="login.php">Login</a></li><?php } ?>
                  <?php if(isset($_SESSION['login'])&&$_SESSION['login']==true){ ?><li><a href="liste.php">Gérer</a></li>
                  <li class="active"><a href="create.php">Créer</a></li>
				  <li><a href="logout.php">Logout</a></li><?php } ?>
               </ul>
            </div>
            <!--/.nav-collapse -->
         </div>
      </nav>
	<div style="display:none;position:absolute;height:100%;width:100%;background-color:rgba(204, 204, 204, 0.3);text-align:center;z-index:100"  id="ajax-loading"><img src="http://futureofmuseums.eu/wp-content/themes/museum/img/loader.gif" alt="Loading"/></div>

    <div class="container">
	<div class="starter-template">

      <form id="rendered-form" class="col-sm-6 col-sm-push-3 w">
      	<div class="form-group">
        	<h1>Ton évènement</h1>
        	<h3>Créer vos événements en moins d'une minute !</h3>
      	</div>
      	<div class="form-group">
	    	<label for="name">Nom de l'évènement <span class="required">*</span> </label> 
	    	<input type="text" required placeholder="Entrer le nom de l'évènement" class="form-control text-input" name="name" id="name" >
    	</div>
    	<div class="form-group">
	    	<label for="datestart">Date de début <span class="required">*</span> </label> 
	    	<input type="date" required class="form-control calendar" name="datestart" id="datestart">
		</div>
    	<div class="form-group">
    		<label for="dateend">Date de fin <span class="required">*</span></label> 
    		<input type="date" required class="form-control calendar" name="dateend" id="dateend">
		</div>
    	<div class="form-group">
    		<button type="submit" class="btn btn-primary button-input" name="sendbtn" id="sendbtn">Créer l'évènement</button>
		</div>
</form>
</div>
    </div><!-- /.container -->
	<footer class="footer">
      <div class="container">
        <p class="text-muted">Email : <a href="mailto:contact@fiesta.ch">contact@fiesta.ch</a> / Tel : 0123 456 789</p>
      </div>
    </footer>



<script type="text/javascript">
	 $('#sendbtn').click(function (e) {
        e.preventDefault();
		$('#ajax-loading').show();
		var beginning = $('#datestart').val();
		var end = $('#dateend').val();
		var name = $('#name').val();
		source = {
			 "beginning": beginning,
			 "end": end,
			 "name": name,
			};
        $.ajax({
            type: "POST",
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            url: "https://projetfiesta-1372.appspot.com/_ah/api/eventEntityApi/v1/eventEntity?fields=beginning%2Cend%2Cname",
            data : JSON.stringify(source),
            success: function (data) {
                alert("Votre évènement a bien été créé !");
				$('#ajax-loading').hide();
            },
            error: function (error) {
                console.log(error);
				$('#ajax-loading').hide();
            }
        });
    });
</script>
</body>
</html>



