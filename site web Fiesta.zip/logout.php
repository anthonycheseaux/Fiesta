<?php
	session_start();
	if(!isset($_SESSION['login'])){
		$_SESSION['login'] = false;
	}
	if($_SESSION['login']==true){
		$_SESSION['login'] = false;
		header('Location: index.php'); 
	}
?>